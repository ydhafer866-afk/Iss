const coachesData = [
    {
        id: 1,
        name: 'Sarah Johnson',
        specialty: 'Weight Loss & Cardio',
        experience: '8 years',
        certifications: ['NASM-CPT', 'Nutrition Specialist', 'Group Fitness'],
        rating: 4.9,
        reviews: 247,
        image: 'https://i.pravatar.cc/300?img=5',
        bio: 'Specialized in helping clients achieve sustainable weight loss through personalized cardio programs and nutrition guidance.',
        trainingPlans: [
            {
                name: '30-Day Fat Burn Challenge',
                duration: '30 days',
                level: 'Intermediate',
                description: 'High-intensity cardio program designed to maximize fat burning',
                price: 'Free'
            },
            {
                name: 'Beginner Weight Loss',
                duration: '8 weeks',
                level: 'Beginner',
                description: 'Gentle introduction to cardio and strength training for weight loss',
                price: 'Free'
            }
        ],
        weeklyProgress: [
            { week: 1, focus: 'Foundation & Form', exercises: 5, duration: '30 min' },
            { week: 2, focus: 'Building Endurance', exercises: 6, duration: '35 min' },
            { week: 3, focus: 'Intensity Increase', exercises: 6, duration: '40 min' },
            { week: 4, focus: 'Peak Performance', exercises: 7, duration: '45 min' }
        ]
    },
    {
        id: 2,
        name: 'Mike Rodriguez',
        specialty: 'Muscle Building & Strength',
        experience: '12 years',
        certifications: ['CSCS', 'Olympic Weightlifting', 'Sports Nutrition'],
        rating: 4.8,
        reviews: 189,
        image: 'https://i.pravatar.cc/300?img=12',
        bio: 'Former competitive bodybuilder with expertise in hypertrophy training and strength development for all levels.',
        trainingPlans: [
            {
                name: 'Muscle Mass Builder',
                duration: '12 weeks',
                level: 'Intermediate',
                description: 'Progressive overload program for maximum muscle growth',
                price: 'Free'
            },
            {
                name: 'Strength Foundation',
                duration: '6 weeks',
                level: 'Beginner',
                description: 'Build a solid strength base with compound movements',
                price: 'Free'
            }
        ],
        weeklyProgress: [
            { week: 1, focus: 'Compound Movements', exercises: 6, duration: '60 min' },
            { week: 2, focus: 'Progressive Overload', exercises: 7, duration: '65 min' },
            { week: 3, focus: 'Muscle Isolation', exercises: 8, duration: '70 min' },
            { week: 4, focus: 'Peak Week', exercises: 8, duration: '75 min' }
        ]
    },
    {
        id: 3,
        name: 'Emily Chen',
        specialty: 'Yoga & Flexibility',
        experience: '10 years',
        certifications: ['RYT-500', 'Pilates Instructor', 'Mobility Specialist'],
        rating: 5.0,
        reviews: 312,
        image: 'https://i.pravatar.cc/300?img=9',
        bio: 'Yoga instructor focused on improving flexibility, mobility, and mind-body connection through mindful movement.',
        trainingPlans: [
            {
                name: 'Flexibility Fundamentals',
                duration: '4 weeks',
                level: 'All Levels',
                description: 'Improve flexibility and reduce muscle tension',
                price: 'Free'
            },
            {
                name: 'Power Yoga Program',
                duration: '8 weeks',
                level: 'Intermediate',
                description: 'Dynamic yoga flows for strength and flexibility',
                price: 'Free'
            }
        ],
        weeklyProgress: [
            { week: 1, focus: 'Basic Poses & Breathing', exercises: 8, duration: '45 min' },
            { week: 2, focus: 'Flow Sequences', exercises: 10, duration: '50 min' },
            { week: 3, focus: 'Advanced Poses', exercises: 12, duration: '55 min' },
            { week: 4, focus: 'Integration & Balance', exercises: 12, duration: '60 min' }
        ]
    },
    {
        id: 4,
        name: 'David Martinez',
        specialty: 'HIIT & Functional Training',
        experience: '7 years',
        certifications: ['CrossFit L2', 'HIIT Specialist', 'Functional Movement'],
        rating: 4.7,
        reviews: 156,
        image: 'https://i.pravatar.cc/300?img=15',
        bio: 'High-intensity training expert helping clients build functional strength and explosive power.',
        trainingPlans: [
            {
                name: '20-Min HIIT Blast',
                duration: '4 weeks',
                level: 'All Levels',
                description: 'Short, intense workouts for busy schedules',
                price: 'Free'
            },
            {
                name: 'Functional Fitness',
                duration: '10 weeks',
                level: 'Intermediate',
                description: 'Build real-world strength and conditioning',
                price: 'Free'
            }
        ],
        weeklyProgress: [
            { week: 1, focus: 'HIIT Basics', exercises: 6, duration: '20 min' },
            { week: 2, focus: 'Intensity Ramp', exercises: 7, duration: '25 min' },
            { week: 3, focus: 'Complex Movements', exercises: 8, duration: '30 min' },
            { week: 4, focus: 'Max Effort', exercises: 8, duration: '30 min' }
        ]
    }
];
